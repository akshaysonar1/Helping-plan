<footer id="footer">
    <div class="container py-4">
        <div class="row">
            <div class="col-xl-12">
                <div class="d-flex gap-3 flex-center">
                    <a href="<?php echo e(route('user.privacy')); ?>">
                        <p class="mb-0">Privacy Policy</p>
                    </a>
                    <a href="<?php echo e(route('user.term')); ?>">
                        <p class="mb-0">Terms & Conditions</p>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="container ">
        <div class="copyright">
            &copy; Copyright <strong><span>BizLand</span></strong>. All Rights Reserved
        </div>

        <div class="credits">
            Designed by <a href="#">BootstrapMade</a>
        </div>
    </div>
</footer><!-- End Footer -->
<?php /**PATH /opt/lampp/htdocs/umoney/resources/views/user/layouts/footer.blade.php ENDPATH**/ ?>