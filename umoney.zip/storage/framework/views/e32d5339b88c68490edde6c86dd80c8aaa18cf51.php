<?php $__env->startSection('content'); ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Document</title>
        <style>
            button {
            width: 5%;
            padding: 8px;
            border-radius: 5px;
            border: none;
            background: #3b43d6;
            font-size: 14px;
            font-weight: 600;
            color: #fff;
            background-color: #4e73df;
            border-color: #4e73df;
            margin-top: 20px;
        }
            </style>
    </head>

    <body>
        <div class="container">
            <div class="card o-hidden border-0 shadow-lg my-5">
                <div class="card-body p-0">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">CUSTOMER DETAILS</h6>
                    </div>

                    <div class="card-body p-6">
                        <table id="customerDetails" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Sr.no</th>
                                    <th>Date</th>
                                    <th>Unique No</th>
                                    <th>Name</th>
                                    <th>Mobile No.</th>
                                    <th>Provide Help</th>
                                    <th>Get Help</th>
                                    <th>Remark</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $i = 1;
                                ?>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i); ?></td>
                                        <td><?php echo e($row->created_at); ?></td>
                                        <td><?php echo e($row->customer_id); ?></td>
                                        <td><?php echo e($row->name); ?></td>
                                        <td><?php echo e($row->mobile); ?></td>
                                        <td><?php echo e($row->provide_help_ammount); ?></td>
                                        <td><?php echo e($row->get_help_ammount); ?></td>
                                        <td>
                                            <?php if(empty($row->provide_help_ammount)): ?>
                                                <button type="button" class="btn btn-danger"
                                                    style="width:90px">empty</button>
                                        </td>
                                    <?php else: ?>
                                        <?php if($row->ammount_Received == $row->get_help_ammount): ?>
                                            <button type="button" class="btn btn-success" style="width:90px ">Done</button>
                                            </td>
                                        <?php else: ?>
                                            <button type="button"
                                                class="btn btn-warning"style="width:90px">Pending</button></td>
                                        <?php endif; ?>
                                <?php endif; ?>
                                </tr>
                                <?php
                                    $i++;
                                ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                            <tfoot>

                            </tfoot>
                        </table>

                    </div>
                    
                </div>
            </div>
        </div>
    </body>

    </html>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-js'); ?>

<script>
$(document).ready(function() {
    $('#customerDetails').DataTable( {
        dom: 'lBfrtip',
        // Bfrtip
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print',
        ]
    } );
} );
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/umoney/resources/views/customer_details/customer_details.blade.php ENDPATH**/ ?>