<header id="header" class="d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">
        <h1 class="logo"><a href="<?php echo e(route('index')); ?>"><img src="<?php echo e(asset('user/assets/img/logo.svg')); ?>"
                    alt=""></a></h1>
        <nav id="navbar" class="navbar">
            <ul>
                <li><a class="nav-link scrollto" href="<?php echo e(route('index')); ?>">HOME</a></li>
                <?php if(!empty(Auth::user()->id)): ?>
                <li><a class="nav-link scrollto" href="<?php echo e(route('user.dashboard.show')); ?>">DASHBOARD</a></li>
                <?php endif; ?>
                <li><a class="nav-link scrollto" href="<?php echo e(route('user.contact')); ?>">CONTACT US</a></li>
                <?php if(empty(Auth::user()->id) || Auth::user()->user_type == '1'): ?>
                    
                    <li><a href="<?php echo e(route('user.login')); ?>"><button type="submit" class="btn btn-logout-1">Login</button></a></li>
                    <?php else: ?>
                <li>
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('Post'); ?>
               <button type="submit" class="btn btn-logout-1">Logout</button></li>
                </form>
                
                    
                <?php endif; ?>
            </ul>
            <i class="bi bi-list mobile-nav-toggle"></i>
        </nav>
    </div>
</header>
<?php /**PATH /opt/lampp/htdocs/umoney/resources/views/user/layouts/header.blade.php ENDPATH**/ ?>