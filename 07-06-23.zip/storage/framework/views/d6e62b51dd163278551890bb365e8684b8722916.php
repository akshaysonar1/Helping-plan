<?php $__env->startSection('content'); ?>
    <div class="container">

        <div class="card o-hidden border-0 shadow-lg my-5">
            <?php if(Session::has('message')): ?>
            <p class="alert alert-info session-error"><?php echo e(Session::get('message')); ?></p>
        <?php endif; ?>
            <div class="card-body p-0">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">CONTACT US LIST</h6>
                </div>
                <!-- DataTales Example -->

                <div class="card-body">
                    <div class="table-responsive">
                        <table id="dataTable" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Sr.no</th>
                                    <th>Name</th>
                                    <th>Number</th>
                                    <th>Subject</th>
                                    <th>Message</th>
                                     

                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $i = 1;
                                ?>
                                <?php $__currentLoopData = $contact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i); ?></td>
                                        <td><?php echo e($row->user_name); ?></td>
                                        <td><?php echo e($row->mobile); ?></td>
                                        <td><?php echo e($row->subject); ?></td>
                                        <td><?php echo e($row->user_message); ?></td>
                                        
                                       

                                     

                                    </tr>
                                    <?php
                                        $i++;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                            <tfoot>

                            </tfoot>
                        </table>
                    </div>
                </div>
                <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
                <script>
                    $(document).ready(function() {
                        $(".examps").click(function() {
                            var mobile = $(this).data('mobile');
                            $("#mobile").val(mobile);


                        });
                    });
                </script>
                

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-js'); ?>
<script>
    $("document").ready(function() {
        setTimeout(function() {
            $(".session-error").remove();
        }, 5000); // 5 secs
    });
</script>
<script>
$(document).ready(function() {
            $('#dataTable').DataTable({
                // "aaSorting": [
                //     [4, "asc"]
                // ]
            });
        });
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/umoney/resources/views/customer_details/contactus.blade.php ENDPATH**/ ?>