<?php $__env->startSection('master'); ?>

<section id="about" class="about section-bg">
    <div class="container" data-aos="fade-up">
        <?php if(Session::has('message')): ?>
        <p class="alert alert-info"><?php echo e(Session::get('message')); ?></p>
        <?php endif; ?>
        <div class="section-title">

            <h2>Dashboard</h2>
            <h3>Find Out More <span>Dashboard</span></h3>
        </div>
    </div>
</section>
<section class="adjust-margin">
    <div class="container">
        <div class="row">
            <div class="col-xl-3 col-lg-3 ">
                <div class="tab-background">
                    <!-- <div class="sidebar-flex"> -->
                    <div class="profile-img">
                        <img src="assets/img/testimonials-bg.jpg">
                    </div>
                    <div class="tab-menu">
                        <ul class="nav nav-pills tab-list" id="myTab" role="tablist">
                            <li class="nav-item typo-tab" role="presentation">
                                <button class="nav-link tab-text active tab-padding w-100 text-left" id="Dashboard"
                                    data-bs-toggle="tab" data-bs-target="#Dashboard-tab-pane" type="button" role="tab"
                                    aria-controls="home-tab-pane" aria-selected="true">Dashboard</button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link tab-text tab-padding w-100" id="profile-tab"
                                    data-bs-toggle="tab" data-bs-target="#profile-tab-pane" type="button" role="tab"
                                    aria-controls="home-tab-pane" aria-selected="true">Profile</button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link tab-text tab-padding w-100" id="provide-tab"
                                    data-bs-toggle="tab" data-bs-target="#provide-tab-pane" type="button" role="tab"
                                    aria-controls="home-tab-pane" aria-selected="true">Provide
                                    Help</button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link tab-text tab-padding w-100" id="get-tab" data-bs-toggle="tab"
                                    data-bs-target="#get-tab-pane" type="button" role="tab"
                                    aria-controls="home-tab-pane" aria-selected="true">Get
                                    Help</button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link tab-text tab-padding w-100" id="history-tab"
                                    data-bs-toggle="tab" data-bs-target="#history-tab-pane" type="button" role="tab"
                                    aria-controls="home-tab-pane" aria-selected="true">History</button>
                            </li>
                        </ul>
                    </div>
                    <div class="Log-out-btn">
                        <form action="<?php echo e(route('logout')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-logout w-100">Logout</button>
                        </form>
                    </div>
                    <!-- </div> -->
                </div>
            </div>
            <div class="col-xl-9 col-lg-9 ">
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="Dashboard-tab-pane" role="tabpanel"
                        aria-labelledby="Dashboard" tabindex="0">
                        <div class="">
                            <div class="">
                                <div class="row">

                                    <div class="col-xl-6">
                                        <?php if(isset($users) && count($users) > 0 && Auth::user()->status==1): ?>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php if($user->tran_status!=2): ?>
                                        <div class="pay-card responsive-card">
                                            <div class=" d-flex justify-content-between">
                                                <div class="d-flex gap-3">
                                                    <div class="">
                                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                                            xmlns="http://www.w3.org/2000/svg">
                                                            <circle cx="10" cy="10" r="10" fill="#FF3D3D" />
                                                        </svg>
                                                    </div>
                                                    <div class="">
                                                        <p class="id-text">
                                                            <?php echo e($user->receiverUser ? $user->receiverUser->customer_id :
                                                            ''); ?>

                                                        </p>
                                                        
                                                        
                                                    </div>
                                                    <div class="">
                                                        <p class="name-text mb-1"> Name : <span class="name-para"><?php echo e($user->receiverUser ? $user->receiverUser->name : ''); ?></span>
                                                        </p>
                                                        <p class="name-text mb-1"> Bank : <span class="name-para"><?php echo e($user->receiverUser ? $user->receiverUser->bank_name :
                                                                ''); ?></span>
                                                        </p>
                                                        <p class="name-text mb-1"> Mo.No : <span class="name-para"><?php echo e($user->receiverUser ? $user->receiverUser->mobile : ''); ?></span>
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="">
                                                    <input type="hidden" id="start_date_timer"
                                                        value="<?php echo e(isset($currentDate) && !empty($currentDate) ? $currentDate : date("
                                                        Y-m-d h:i:s")); ?>">
                                                    <input type="hidden" id="end_date_timer"
                                                        value="<?php echo e($user->end_date); ?>">
                                                    <input type="hidden" id="payment_success_date"
                                                        value="<?php echo e($user->payment_success_date); ?>">
                                                    <input type="hidden" id="payment_status" class="payment_status"
                                                        value="<?php echo e($user->tran_status); ?>">
                                                    <p class="name-text mb-1" id="user_timer"></p>

                                                    <p class="name-text mb-1">
                                                        Rs.<?php echo e($user->get_ammount); ?> </p>

                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-xl-12 d-flex justify-content-end gap-2">
                                                    
                                                    <button type="button" class="btn btn-payment" data-toggle="modal"
                                                        data-target="#exampleModal" data-whatever="@mdo">Payment
                                                        Image</button>
                                                    <div class="modal fade" id="exampleModal" tabindex="-1"
                                                        role="dialog" aria-labelledby="exampleModalLabel"
                                                        aria-hidden="true">
                                                        <div class="modal-dialog" role="document">
                                                            <form action="<?php echo e(route('user.payment')); ?>" method="POST"
                                                                enctype="multipart/form-data">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('post'); ?>
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title" id="exampleModalLabel">
                                                                            Upload
                                                                            Payment Image</h5>
                                                                        <button type="button" class="close"
                                                                            data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <div class="form-group">
                                                                            <label for="formFileMultiple"
                                                                                class="form-label">Payment
                                                                                Image</label>
                                                                            <input class="form-control" type="file"
                                                                                name="image" id="formFileMultiple"
                                                                                required>
                                                                            <input type="hidden" name="receiver_id"
                                                                                value="<?php echo e($user->receiverUser ? $user->receiverUser->id : ''); ?>">
                                                                            <input type="hidden" name="transaction_id"
                                                                                value="<?php echo e($user->id); ?>">
                                                                            <input type="hidden" name="get_amount"
                                                                                value="<?php echo e($user->get_ammount); ?>">
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-secondary"
                                                                            data-dismiss="modal">Close</button>
                                                                        <button type="submit"
                                                                            class="btn btn-primary">Upload</button>
                                                                    </div>
                                                                </div>
                                                            </form>
                                                        </div>

                                                    </div>
                                                    <div class="details-tip">
                                                        <button type="button"
                                                            class="btn btn-payment details-show">Details</button>
                                                        <div class="tooltip-content details-div">
                                                            <p class="name-text mb-1"> Name : <span class="name-para"><?php echo e($user->receiverUser ? $user->receiverUser->name : ''); ?></span>
                                                            </p>
                                                            <p class="name-text mb-1"> Mobile No. : <span
                                                                    class="name-para"><?php echo e($user->receiverUser ?
                                                                    $user->receiverUser->mobile : ''); ?></span>
                                                            </p>
                                                            <p class="name-text mb-1"> Ifsc Code : <span
                                                                    class="name-para"><?php echo e($user->receiverUser ?
                                                                    $user->receiverUser->ifsc_code : ''); ?></span>
                                                            </p>
                                                            <p class="name-text mb-1"> Account No: <span
                                                                    class="name-para"><?php echo e($user->receiverUser ?
                                                                    $user->receiverUser->account_no : ''); ?></span>
                                                            </p>
                                                            <p class="name-text mb-1"> Upi Link: <span
                                                                    class="name-para"><?php echo e($user->receiverUser ?
                                                                    $user->receiverUser->upi_link : ''); ?></span>
                                                            </p>
                                                            <p class="name-text mb-1"> Phone Pay No: <span
                                                                    class="name-para"><?php echo e($user->receiverUser ?
                                                                    $user->receiverUser->phone_pay_no : ''); ?></span>
                                                            </p>
                                                            <p class="name-text mb-1"> Google Pay No: <span
                                                                    class="name-para"><?php echo e($user->receiverUser ?
                                                                    $user->receiverUser->google_pay_no : ''); ?></span>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php else: ?>

                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php elseif(isset($showusers) && count($showusers) > 0): ?>
                                        
                                        <?php $__currentLoopData = $showusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $show): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="pay-card responsive-card">
                                            <div class=" d-flex justify-content-between">
                                                <div class="d-flex gap-3">
                                                    <div class="">
                                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                                            xmlns="http://www.w3.org/2000/svg">
                                                            <circle cx="10" cy="10" r="10" fill="#7AE868" />
                                                        </svg>
                                                    </div>
                                                    <div class="">
                                                        <p class="id-text">
                                                            <?php echo e($show->receiverUser ? $show->receiverUser->customer_id :
                                                            ''); ?>

                                                        </p>
                                                        
                                                        
                                                    </div>
                                                    <div class="">
                                                        <p class="name-text mb-1"> Name : <span class="name-para"><?php echo e($show->receiverUser ? $show->receiverUser->name : ''); ?></span>
                                                        </p>

                                                        <p class="name-text mb-1"> Bank : <span class="name-para"><?php echo e($show->receiverUser ? $show->receiverUser->bank_name :
                                                                ''); ?></span>
                                                        </p>
                                                        <p class="name-text mb-1"> Mo.No : <span class="name-para"><?php echo e($show->receiverUser ? $show->receiverUser->mobile : ''); ?></span>
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="">
                                                    <input type="hidden" id="start_date_timer"
                                                        value="<?php echo e(isset($currentDate) && !empty($currentDate) ? $currentDate : date("
                                                        Y-m-d h:i:s")); ?>">
                                                    <input type="hidden" id="end_date_timer"
                                                        value="<?php echo e($show->end_date); ?>">
                                                    <input type="hidden" id="payment_success_date"
                                                        value="<?php echo e($show->payment_success_date); ?>">
                                                    <input type="hidden" id="payment_status" class="payment_status"
                                                        value="<?php echo e($show->tran_status); ?>">
                                                    <p class="name-text mb-1" id="user_timer"></p>

                                                    <p class="name-text mb-1">
                                                        Rs.<?php echo e($show->get_ammount); ?> </p>

                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-xl-12 d-flex justify-content-end gap-2">

                                                    

                                                    <button type="button" class="btn btn-payment" data-toggle="modal"
                                                        data-target=".<?php echo e($show->id); ?>-modal4-lg"
                                                        data-id="<?php echo e($show->show); ?>" data-image="<?php echo e($show->image); ?>">View
                                                        Image</button>


                                                    <!-- Large modal -->


                                                    <div class="modal fade bd-example-modal-lg <?php echo e($show->id); ?>-modal4-lg"
                                                        tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
                                                        aria-hidden="true">
                                                        <div class="modal-dialog modal-lg">
                                                            <div class="modal-content">

                                                                <img id="image"
                                                                    src="<?php echo e(asset('user/assets/img/payment/'.$show->image)); ?>" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="modal fade" id="exampleModal" tabindex="-1"
                                                        role="dialog" aria-labelledby="exampleModalLabel"
                                                        aria-hidden="true">
                                                        <div class="modal-dialog" role="document">
                                                            <form action="<?php echo e(route('user.payment')); ?>" method="POST"
                                                                enctype="multipart/form-data">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('post'); ?>
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title" id="exampleModalLabel">
                                                                            Upload
                                                                            Payment Image</h5>
                                                                        <button type="button" class="close"
                                                                            data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <div class="form-group">
                                                                            <label for="formFileMultiple"
                                                                                class="form-label">Payment
                                                                                Image</label>
                                                                            <input class="form-control" type="file"
                                                                                name="image" id="formFileMultiple"
                                                                                required>
                                                                            <input type="hidden" name="receiver_id"
                                                                                value="<?php echo e($show->receiverUser ? $show->receiverUser->id : ''); ?>">
                                                                            <input type="hidden" name="transaction_id"
                                                                                value="<?php echo e($show->id); ?>">
                                                                            <input type="hidden" name="get_amount"
                                                                                value="<?php echo e($show->get_ammount); ?>">
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-secondary"
                                                                            data-dismiss="modal">Close</button>
                                                                        <button type="submit"
                                                                            class="btn btn-primary">Upload</button>
                                                                    </div>
                                                                </div>
                                                            </form>
                                                        </div>

                                                    </div>
                                                    <div class="details-tip">
                                                        <button type="button"
                                                            class="btn btn-payment details-show">Details</button>
                                                        <div class="tooltip-content details-div">
                                                            
                                                            <p class="name-text mb-1"> Name : <span class="name-para"><?php echo e($show->receiverUser ? $show->receiverUser->name : ''); ?></span>
                                                            </p>
                                                            <p class="name-text mb-1"> Mobile No. : <span
                                                                    class="name-para"><?php echo e($show->receiverUser ?
                                                                    $show->receiverUser->mobile : ''); ?></span>
                                                            </p>
                                                            <p class="name-text mb-1"> Ifsc Code : <span
                                                                    class="name-para"><?php echo e($show->receiverUser ?
                                                                    $show->receiverUser->ifsc_code : ''); ?></span>
                                                            </p>
                                                            <p class="name-text mb-1"> Account No: <span
                                                                    class="name-para"><?php echo e($show->receiverUser ?
                                                                    $show->receiverUser->account_no : ''); ?></span>
                                                            </p>
                                                            <p class="name-text mb-1"> Upi Link: <span
                                                                    class="name-para"><?php echo e($show->receiverUser ?
                                                                    $show->receiverUser->upi_link : ''); ?></span>
                                                            </p>
                                                            <p class="name-text mb-1"> Phone Pay No: <span
                                                                    class="name-para"><?php echo e($show->receiverUser ?
                                                                    $show->receiverUser->phone_pay_no : ''); ?></span>
                                                            </p>
                                                            <p class="name-text mb-1"> Google Pay No: <span
                                                                    class="name-para"><?php echo e($show->receiverUser ?
                                                                    $show->receiverUser->google_pay_no : ''); ?></span>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>

                                    

                                    <div class="col-xl-6">
                                        <?php $__currentLoopData = $conform; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <div class="pay-card-1">

                                            <div class=" d-flex justify-content-between">
                                                <div class="d-flex gap-3">
                                                    <div class="">
                                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                                            xmlns="http://www.w3.org/2000/svg">
                                                            <circle cx="10" cy="10" r="10" fill="#7AE868" />
                                                        </svg>
                                                    </div>
                                                    <div class="">
                                                        <p class="id-text"><?php echo e($coform->customer_id); ?></p>
                                                        <p class="date-text">
                                                            <?php echo e($coform->created_at->todatestring()); ?></p>
                                                    </div>
                                                    <div class="">
                                                        <p class="name-text mb-1"> Name : <span class="name-para"><?php echo e($coform->name); ?></span></p>
                                                        <p class="name-text mb-1"> Bank : <span class="name-para"><?php echo e($coform->bank_name); ?></span>
                                                        </p>
                                                        <p class="name-text mb-1"> Mo.No : <span class="name-para"><?php echo e($coform->mobile); ?></span></p>
                                                    </div>
                                                </div>
                                                <div class="">
                                                    <?php if($coform->tran_status == '1'): ?>

                                                    <?php else: ?>
                                                    <p class="name-text mb-1">47:38:25</p>
                                                    <?php endif; ?>
                                                    <p class="name-text mb-1">Rs.<?php echo e($coform->get_ammount); ?></p>
                                                </div>
                                            </div>




                                            <div class="row">


                                                <form action="<?php echo e(route('user.conformetion', $coform->sender_id)); ?>"
                                                    method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('post'); ?>
                                                    <div class="col-xl-12 d-flex justify-content-end gap-2">


                                                        <?php if($coform->tran_status == '1'): ?>
                                                        <button type="button" class="btn btn-payment">Conformation
                                                            Done</button>
                                                        <?php else: ?>
                                                        <button type="submit" class="btn btn-payment">confirm</button>
                                                        <?php endif; ?>

                                                        

                                                        <button type="button" class="btn btn-payment"
                                                            data-toggle="modal"
                                                            data-target=".<?php echo e($coform->id); ?>-modal1-lg"
                                                            data-id="<?php echo e($coform->user_id); ?>"
                                                            data-image="<?php echo e($coform->image); ?>">View
                                                            Image</button>


                                                        <!-- Large modal -->


                                                        <div class="modal fade bd-example-modal-lg <?php echo e($coform->id); ?>-modal1-lg"
                                                            tabindex="-1" role="dialog"
                                                            aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                                            <div class="modal-dialog modal-lg">
                                                                <div class="modal-content">

                                                                    <img id="image"
                                                                        src="<?php echo e(asset('user/assets/img/payment/'.$coform->image)); ?>" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                        



                                                        <?php if($coform->tran_status == '1'): ?>

                                                        <?php else: ?>

                                                        <div class="details-tip">
                                                            <button type="button"
                                                                class="btn btn-payment details-show">Details</button>
                                                            <div class="tooltip-content details-div">

                                                                <p class="name-text mb-1"> Name : <span
                                                                        class="name-para"><?php echo e($coform->name); ?></span>
                                                                </p>
                                                                <p class="name-text mb-1"> Mobile No. : <span
                                                                        class="name-para"><?php echo e($coform->mobile); ?></span></p>
                                                                <p class="name-text mb-1"> Ifsc Code : <span
                                                                        class="name-para"><?php echo e($coform->ifsc_code); ?></span>
                                                                </p>
                                                                <p class="name-text mb-1"> Account No: <span
                                                                        class="name-para"><?php echo e($coform->account_no); ?></span>
                                                                </p>
                                                                <p class="name-text mb-1"> Upi Link: <span
                                                                        class="name-para"><?php echo e($coform->upi_link); ?></span></p>
                                                                <p class="name-text mb-1"> Phone Pay No: <span
                                                                        class="name-para"><?php echo e($coform->phone_pay_no); ?></span>
                                                                </p>
                                                                <p class="name-text mb-1"> Google Pay No: <span
                                                                        class="name-para"><?php echo e($coform->google_pay_no); ?></span>
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <?php endif; ?>

                                                    </div>

                                                </form>
                                            </div>

                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>

                                </div>
                            </div>

                        </div>

                    </div>


                    <!-- profile-tab-content -->

                    <div class="tab-pane fade" id="profile-tab-pane" role="tabpanel" aria-labelledby="profile-tab"
                        tabindex="0">
                        <form action="<?php echo e(route('user.profileupdate', Auth::user()->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('post'); ?>
                            <div class="row mb-5">
                                <div class="">
                                    <div class="col-xl-12">
                                        <h4 class="profile-tag">Personal Detail</h4>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xl-6 form-adjust">
                                        <label>Name</label>
                                        <input type="text" placeholder="Name by Bank name" class="form-control"
                                            name="name" value="<?php echo e(Auth::user()->name); ?>">
                                    </div>
                                    <div class="col-xl-6 mb-3 form-adjust">
                                        <label>Mobile No.</label>
                                        <input type="text" placeholder="10 digit mobile no." class="form-control"
                                            value="<?php echo e(Auth::user()->mobile); ?>" readonly>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xl-4 mb-3 form-class form-adjust">
                                        <label>State</label>
                                        <input class="form-control" name="state"
                                            value="<?php echo e(Auth::user()->state); ?>"></input>
                                    </div>
                                    <div class="col-xl-4 mb-3 form-class form-adjust">
                                        <label>City</label>
                                        <input class="form-control" name="city"
                                            value="<?php echo e(Auth::user()->city); ?>"></input>
                                    </div>
                                    <div class="col-xl-4 mb-3 form-class form-adjust">
                                        <label>Pin Code</label>
                                        <input class="form-control" name="pin_code"
                                            value="<?php echo e(Auth::user()->pin_code); ?>"></input>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xl-12 mb-3">
                                    <h4 class="profile-tag">Bank Detail</h4>
                                </div>
                                <div class="row">
                                    <div class="col-xl-6 mb-3 form-class form-adjust">
                                        <label>Bank Name</label>
                                        <input type="text" placeholder="Name by bank name" class="form-control"
                                            name="bank_name" value="<?php echo e(Auth::user()->bank_name); ?>">
                                    </div>
                                    <div class="col-xl-6 mb-3 form-class form-adjust">
                                        <label>A/C No.</label>
                                        <input type="text" placeholder="xxxxxxxxxxxxxxxx" class="form-control"
                                            name="account_no" value="<?php echo e(Auth::user()->account_no); ?>"
                                            oninput="process(this)" maxlength="20">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xl-6 mb-3 form-class form-adjust">
                                        <label>IFSC CODE</label>
                                        <input type="text" placeholder="SBIN001992" class="form-control"
                                            name="ifsc_code" value="<?php echo e(Auth::user()->ifsc_code); ?>" onkeyup="
                                    var start = this.selectionStart;
                                    var end = this.selectionEnd;
                                    this.value = this.value.toUpperCase();
                                    this.setSelectionRange(start, end);
                                  ">
                                    </div>
                                    <div class="col-xl-6 mb-3 form-class form-adjust">
                                        <label>Phone Pay No.</label>
                                        <input type="text" placeholder="99854854589" class="form-control"
                                            name="phone_pay_no" value="<?php echo e(Auth::user()->phone_pay_no); ?>"
                                            oninput="process(this)" maxlength="10">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xl-6 mb-3 form-class form-adjust">
                                        <label>Google Pay No.</label>
                                        <input type="text" placeholder="99854854589" class="form-control"
                                            name="google_pay_no" value="<?php echo e(Auth::user()->google_pay_no); ?>"
                                            oninput="process(this)" maxlength="10">
                                    </div>
                                    <div class="col-xl-6 mb-3 form-class form-adjust">
                                        <label>Upi Link</label>
                                        <input type="text" placeholder="99854854589@ybl" class="form-control"
                                            name="upi_link" value="<?php echo e(Auth::user()->upi_link); ?>">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xl-12">
                                        
                                        <button type="submit" class="btn btn-form-1">Save</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>

                    <div class="tab-pane fade" id="provide-tab-pane" role="tabpanel" aria-labelledby="provide-tab"
                        tabindex="0">
                        <div class="row">
                            <div class="col-xl-12">

                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="pay-card responsive-card">
                                    <div class=" d-flex justify-content-between">
                                        <div class="d-flex gap-3">
                                            <div class="">
                                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <circle cx="10" cy="10" r="10" fill="#FF3D3D" />
                                                </svg>
                                            </div>
                                            <div class="">
                                                <p class="id-text">
                                                    <?php echo e($user->receiverUser ? $user->receiverUser->customer_id :
                                                    ''); ?>

                                                </p>
                                                
                                                
                                            </div>
                                            <div class="">
                                                <p class="name-text mb-1"> Name : <span class="name-para"><?php echo e($user->receiverUser ? $user->receiverUser->name : ''); ?></span>
                                                </p>
                                                <p class="name-text mb-1"> Bank : <span class="name-para"><?php echo e($user->receiverUser ? $user->receiverUser->bank_name :
                                                        ''); ?></span>
                                                </p>
                                                <p class="name-text mb-1"> Mo.No : <span class="name-para"><?php echo e($user->receiverUser ? $user->receiverUser->mobile : ''); ?></span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="">
                                            <input type="hidden" id="start_date_timer"
                                                        value="<?php echo e(isset($currentDate) && !empty($currentDate) ? $currentDate : date("
                                                        Y-m-d h:i:s")); ?>">
                                                    <input type="hidden" id="end_date_timer"
                                                        value="<?php echo e($user->end_date); ?>">
                                                    <input type="hidden" id="payment_success_date"
                                                        value="<?php echo e($user->payment_success_date); ?>">
                                                    <input type="hidden" id="payment_status" class="payment_status"
                                                        value="<?php echo e($user->tran_status); ?>">
                                                    <p class="name-text mb-1" id="user1_timer"></p>

                                            <p class="name-text mb-1">
                                                Rs.<?php echo e($user->get_ammount); ?> </p>

                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xl-12 d-flex justify-content-end gap-2">
                                            
                                            <button type="button" class="btn btn-payment" data-toggle="modal"
                                                data-target="#exampleModal1" data-whatever="@mdo">Payment
                                                Image</button>
                                            <div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog"
                                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <form action="<?php echo e(route('user.payment')); ?>" method="POST"
                                                        enctype="multipart/form-data">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('post'); ?>
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">
                                                                    Upload
                                                                    Payment Image</h5>
                                                                <button type="button" class="close" data-dismiss="modal"
                                                                    aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="form-group">
                                                                    <label for="formFileMultiple"
                                                                        class="form-label">Payment
                                                                        Image</label>
                                                                    <input class="form-control" type="file" name="image"
                                                                        id="formFileMultiple" required>
                                                                    <input type="hidden" name="receiver_id"
                                                                        value="<?php echo e($user->receiverUser ? $user->receiverUser->id : ''); ?>">
                                                                    <input type="hidden" name="transaction_id"
                                                                        value="<?php echo e($user->id); ?>">
                                                                    <input type="hidden" name="get_amount"
                                                                        value="<?php echo e($user->get_ammount); ?>">
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary"
                                                                    data-dismiss="modal">Close</button>
                                                                <button type="submit"
                                                                    class="btn btn-primary">Upload</button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>

                                            </div>
                                            <div class="details-tip">
                                                <button type="button"
                                                    class="btn btn-payment details-show">Details</button>
                                                <div class="tooltip-content details-div">
                                                    <p class="name-text mb-1"> Name : <span class="name-para"><?php echo e($user->receiverUser ? $user->receiverUser->name : ''); ?></span>
                                                    </p>
                                                    <p class="name-text mb-1"> Mobile No. : <span class="name-para"><?php echo e($user->receiverUser ?
                                                            $user->receiverUser->mobile : ''); ?></span>
                                                    </p>
                                                    <p class="name-text mb-1"> Ifsc Code : <span class="name-para"><?php echo e($user->receiverUser ?
                                                            $user->receiverUser->ifsc_code : ''); ?></span>
                                                    </p>
                                                    <p class="name-text mb-1"> Account No: <span class="name-para"><?php echo e($user->receiverUser ?
                                                            $user->receiverUser->account_no : ''); ?></span>
                                                    </p>
                                                    <p class="name-text mb-1"> Upi Link: <span class="name-para"><?php echo e($user->receiverUser ?
                                                            $user->receiverUser->upi_link : ''); ?></span>
                                                    </p>
                                                    <p class="name-text mb-1"> Phone Pay No: <span class="name-para"><?php echo e($user->receiverUser ?
                                                            $user->receiverUser->phone_pay_no : ''); ?></span>
                                                    </p>
                                                    <p class="name-text mb-1"> Google Pay No: <span class="name-para"><?php echo e($user->receiverUser ?
                                                            $user->receiverUser->google_pay_no : ''); ?></span>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                




                                <?php $__currentLoopData = $showusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $show): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="pay-card responsive-card">
                                    <div class=" d-flex justify-content-between">
                                        <div class="d-flex gap-3">
                                            <div class="">
                                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <circle cx="10" cy="10" r="10" fill="#7AE868" />
                                                </svg>
                                            </div>
                                            <div class="">
                                                <p class="id-text">
                                                    <?php echo e($show->receiverUser ? $show->receiverUser->customer_id :
                                                    ''); ?>

                                                </p>
                                                
                                                
                                            </div>
                                            <div class="">
                                                <p class="name-text mb-1"> Name : <span class="name-para"><?php echo e($show->receiverUser ? $show->receiverUser->name : ''); ?></span>
                                                </p>

                                                <p class="name-text mb-1"> Bank : <span class="name-para"><?php echo e($show->receiverUser ? $show->receiverUser->bank_name :
                                                        ''); ?></span>
                                                </p>
                                                <p class="name-text mb-1"> Mo.No : <span class="name-para"><?php echo e($show->receiverUser ? $show->receiverUser->mobile : ''); ?></span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="">
                                            
                                            <input type="hidden" id="start_date_timer"
                                            value="<?php echo e(isset($currentDate) && !empty($currentDate) ? $currentDate : date("
                                            Y-m-d h:i:s")); ?>">
                                        <input type="hidden" id="end_date_timer"
                                            value="<?php echo e($show->end_date); ?>">
                                        <input type="hidden" id="payment_success_date"
                                            value="<?php echo e($show->payment_success_date); ?>">
                                        <input type="hidden" id="payment_status" class="payment_status"
                                            value="<?php echo e($show->tran_status); ?>">
                                        <p class="name-text mb-1" id="user1_timer"></p>

                                            <p class="name-text mb-1">
                                                Rs.<?php echo e($show->get_ammount); ?> </p>

                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xl-12 d-flex justify-content-end gap-2">
                                            

                                            

                                            <button type="button" class="btn btn-payment examps" data-toggle="modal"
                                                data-target=".<?php echo e($show->id); ?>-modal-lg" data-id="<?php echo e($show->user_id); ?>"
                                                data-image="<?php echo e($show->image); ?>">View
                                                Image</button>


                                            <!-- Large modal -->


                                            <div class="modal fade bd-example-modal-lg <?php echo e($show->id); ?>-modal-lg"
                                                tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
                                                aria-hidden="true">
                                                <div class="modal-dialog modal-lg">
                                                    <div class="modal-content">

                                                        <img id="image"
                                                            src="<?php echo e(asset('user/assets/img/payment/'.$show->image)); ?>" />
                                                    </div>
                                                </div>
                                            </div>
                                            

                                            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog"
                                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <form action="<?php echo e(route('user.payment')); ?>" method="POST"
                                                        enctype="multipart/form-data">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('post'); ?>
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">
                                                                    Upload
                                                                    Payment Image</h5>
                                                                <button type="button" class="close" data-dismiss="modal"
                                                                    aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="form-group">
                                                                    <label for="formFileMultiple"
                                                                        class="form-label">Payment
                                                                        Image</label>
                                                                    <input class="form-control" type="file" name="image"
                                                                        id="formFileMultiple" required>
                                                                    <input type="hidden" name="receiver_id"
                                                                        value="<?php echo e($show->receiverUser ? $show->receiverUser->id : ''); ?>">
                                                                    <input type="hidden" name="transaction_id"
                                                                        value="<?php echo e($show->id); ?>">
                                                                    <input type="hidden" name="get_amount"
                                                                        value="<?php echo e($show->get_ammount); ?>">
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary"
                                                                    data-dismiss="modal">Close</button>
                                                                <button type="submit"
                                                                    class="btn btn-primary">Upload</button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>

                                            </div>
                                            <div class="details-tip">
                                                <button type="button"
                                                    class="btn btn-payment details-show">Details</button>
                                                <div class="tooltip-content details-div">
                                                    <p class="name-text mb-1"> Name : <span class="name-para"><?php echo e($show->receiverUser ? $show->receiverUser->name : ''); ?></span>
                                                    </p>
                                                    <p class="name-text mb-1"> Mobile No. : <span class="name-para"><?php echo e($show->receiverUser ?
                                                            $show->receiverUser->mobile : ''); ?></span>
                                                    </p>
                                                    <p class="name-text mb-1"> Ifsc Code : <span class="name-para"><?php echo e($show->receiverUser ?
                                                            $show->receiverUser->ifsc_code : ''); ?></span>
                                                    </p>
                                                    <p class="name-text mb-1"> Account No: <span class="name-para"><?php echo e($show->receiverUser ?
                                                            $show->receiverUser->account_no : ''); ?></span>
                                                    </p>
                                                    <p class="name-text mb-1"> Upi Link: <span class="name-para"><?php echo e($show->receiverUser ?
                                                            $show->receiverUser->upi_link : ''); ?></span>
                                                    </p>
                                                    <p class="name-text mb-1"> Phone Pay No: <span class="name-para"><?php echo e($show->receiverUser ?
                                                            $show->receiverUser->phone_pay_no : ''); ?></span>
                                                    </p>
                                                    <p class="name-text mb-1"> Google Pay No: <span class="name-para"><?php echo e($show->receiverUser ?
                                                            $show->receiverUser->google_pay_no : ''); ?></span>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="disabled-tab-pane" role="tabpanel" aria-labelledby="disabled-tab"
                            tabindex="0">...</div>
                    </div>
                    <div class="tab-pane fade" id="get-tab-pane" role="tabpanel" aria-labelledby="get-tab" tabindex="0">
                        <div class="row">
                            <div class="col-xl-12">

                                <?php $__currentLoopData = $conform; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="pay-card-1">

                                    <div class=" d-flex justify-content-between">
                                        <div class="d-flex gap-3">
                                            <div class="">
                                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <circle cx="10" cy="10" r="10" fill="#7AE868" />
                                                </svg>
                                            </div>
                                            <div class="">
                                                <p class="id-text"><?php echo e($conf->customer_id); ?></p>
                                                <p class="date-text">
                                                    <?php echo e($conf->created_at->todatestring()); ?></p>
                                            </div>
                                            <div class="">
                                                <p class="name-text mb-1"> Name : <span class="name-para"><?php echo e($conf->name); ?></span></p>
                                                <p class="name-text mb-1"> Bank : <span class="name-para"><?php echo e($conf->bank_name); ?></span>
                                                </p>
                                                <p class="name-text mb-1"> Mo.No : <span class="name-para"><?php echo e($conf->mobile); ?></span></p>
                                            </div>
                                        </div>
                                        <div class="">
                                            <?php if($conf->tran_status == '1'): ?>

                                            <?php else: ?>
                                       
                                            <?php endif; ?>
                                            <p class="name-text mb-1">Rs. <?php echo e($conf->get_ammount); ?></p>
                                        </div>
                                    </div>




                                    <div class="row">




                                        <form action="<?php echo e(route('user.conformetion', $conf->sender_id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('post'); ?>
                                            <div class="col-xl-12 d-flex justify-content-end gap-2">


                                                <?php if($conf->tran_status == '1'): ?>
                                                <button type="button" class="btn btn-payment">Conformation
                                                    Done</button>
                                                <?php else: ?>
                                                <button type="submit" class="btn btn-payment">confirm</button>
                                                <?php endif; ?>




                                                <button type="button" class="btn btn-payment examps" data-toggle="modal"
                                                    data-target=".<?php echo e($conf->id); ?>-modal5-lg"
                                                    data-id="<?php echo e($conf->user_id); ?>" data-image="<?php echo e($conf->image); ?>">View
                                                    Image</button>


                                                <!-- Large modal -->


                                                <div class="modal fade bd-example-modal-lg <?php echo e($conf->id); ?>-modal5-lg"
                                                    tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
                                                    aria-hidden="true">
                                                    <div class="modal-dialog modal-lg">
                                                        <div class="modal-content">

                                                            <img id="image"
                                                                src="<?php echo e(asset('user/assets/img/payment/'.$conf->image)); ?>" />
                                                        </div>
                                                    </div>
                                                </div>


                                                <?php if($conf->tran_status == '1'): ?>

                                                <?php else: ?>

                                                <div class="details-tip">
                                                    <button type="button"
                                                        class="btn btn-payment details-show">Details</button>
                                                    <div class="tooltip-content details-div">

                                                        <p class="name-text mb-1"> Name : <span class="name-para"><?php echo e($conf->name); ?></span>
                                                        </p>
                                                        <p class="name-text mb-1"> Mobile No. : <span
                                                                class="name-para"><?php echo e($conf->mobile); ?></span></p>
                                                        <p class="name-text mb-1"> Ifsc Code : <span
                                                                class="name-para"><?php echo e($conf->ifsc_code); ?></span>
                                                        </p>
                                                        <p class="name-text mb-1"> Account No: <span
                                                                class="name-para"><?php echo e($conf->account_no); ?></span>
                                                        </p>
                                                        <p class="name-text mb-1"> Upi Link: <span class="name-para"><?php echo e($conf->upi_link); ?></span></p>
                                                        <p class="name-text mb-1"> Phone Pay No: <span
                                                                class="name-para"><?php echo e($conf->phone_pay_no); ?></span>
                                                        </p>
                                                        <p class="name-text mb-1"> Google Pay No: <span
                                                                class="name-para"><?php echo e($conf->google_pay_no); ?></span>
                                                        </p>
                                                    </div>
                                                </div>
                                                <?php endif; ?>

                                            </div>

                                        </form>
                                    </div>

                                </div><br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="profile-tab-pane" role="tabpanel" aria-labelledby="profile-tab"
                        tabindex="0">
                        ...</div>
                </div>
                <div class="tab-pane fade" id="history-tab-pane" role="tabpanel" aria-labelledby="history-tab"
                    tabindex="0">
                    <div class="">
                        <div class="">
                            <div class="row">

                                <div class="col-xl-6">



                                    




                                    <?php $__currentLoopData = $showusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $show): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <div class="pay-card responsive-card">
                                        <div class=" d-flex justify-content-between">
                                            <div class="d-flex gap-3">
                                                <div class="">
                                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <circle cx="10" cy="10" r="10" fill="#7AE868" />
                                                    </svg>
                                                </div>
                                                <div class="">
                                                    <p class="id-text">
                                                        <?php echo e($show->receiverUser ? $show->receiverUser->customer_id :
                                                        ''); ?>

                                                    </p>
                                                    
                                                    
                                                </div>
                                                <div class="">
                                                    <p class="name-text mb-1"> Name : <span class="name-para"><?php echo e($show->receiverUser ? $show->receiverUser->name : ''); ?></span>
                                                    </p>

                                                    <p class="name-text mb-1"> Bank : <span class="name-para"><?php echo e($show->receiverUser ? $show->receiverUser->bank_name :
                                                            ''); ?></span>
                                                    </p>
                                                    <p class="name-text mb-1"> Mo.No : <span class="name-para"><?php echo e($show->receiverUser ? $show->receiverUser->mobile : ''); ?></span>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="">
                                                
                                                <input type="hidden" id="start_date_timer"
                                                value="<?php echo e(isset($currentDate) && !empty($currentDate) ? $currentDate : date("
                                                Y-m-d h:i:s")); ?>">
                                            <input type="hidden" id="end_date_timer"
                                                value="<?php echo e($show->end_date); ?>">
                                            <input type="hidden" id="payment_success_date"
                                                value="<?php echo e($show->payment_success_date); ?>">
                                            <input type="hidden" id="payment_status" class="payment_status"
                                                value="<?php echo e($show->tran_status); ?>">
                                            <p class="name-text mb-1" id="user2_timer"></p>

                                                <p class="name-text mb-1">
                                                    Rs.<?php echo e($show->get_ammount); ?> </p>

                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-xl-12 d-flex justify-content-end gap-2">
                                                
                                                

                                                <button type="button" class="btn btn-payment" data-toggle="modal"
                                                    data-target=".<?php echo e($show->id); ?>-modal3-lg" data-id="<?php echo e($show->show); ?>"
                                                    data-image="<?php echo e($show->image); ?>">View
                                                    Image</button>


                                                <!-- Large modal -->


                                                <div class="modal fade bd-example-modal-lg <?php echo e($show->id); ?>-modal3-lg"
                                                    tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
                                                    aria-hidden="true">
                                                    <div class="modal-dialog modal-lg">
                                                        <div class="modal-content">

                                                            <img id="image"
                                                                src="<?php echo e(asset('user/assets/img/payment/'.$show->image)); ?>" />
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="details-tip">
                                                    <button type="button"
                                                        class="btn btn-payment details-show">Details</button>
                                                    <div class="tooltip-content details-div">
                                                        <p class="name-text mb-1"> Name : <span class="name-para"><?php echo e($show->receiverUser ? $show->receiverUser->name : ''); ?></span>
                                                        </p>
                                                        <p class="name-text mb-1"> Mobile No. : <span
                                                                class="name-para"><?php echo e($show->receiverUser ?
                                                                $show->receiverUser->mobile : ''); ?></span>
                                                        </p>
                                                        <p class="name-text mb-1"> Ifsc Code : <span
                                                                class="name-para"><?php echo e($show->receiverUser ?
                                                                $show->receiverUser->ifsc_code : ''); ?></span>
                                                        </p>
                                                        <p class="name-text mb-1"> Account No: <span
                                                                class="name-para"><?php echo e($show->receiverUser ?
                                                                $show->receiverUser->account_no : ''); ?></span>
                                                        </p>
                                                        <p class="name-text mb-1"> Upi Link: <span class="name-para"><?php echo e($show->receiverUser ?
                                                                $show->receiverUser->upi_link : ''); ?></span>
                                                        </p>
                                                        <p class="name-text mb-1"> Phone Pay No: <span
                                                                class="name-para"><?php echo e($show->receiverUser ?
                                                                $show->receiverUser->phone_pay_no : ''); ?></span>
                                                        </p>
                                                        <p class="name-text mb-1"> Google Pay No: <span
                                                                class="name-para"><?php echo e($show->receiverUser ?
                                                                $show->receiverUser->google_pay_no : ''); ?></span>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                                

                                <div class="col-xl-6">
                                    <?php $__currentLoopData = $conform; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="pay-card-1">
                                        <?php if($coform->tran_status == '1'): ?>
                                        <div class=" d-flex justify-content-between">
                                            <div class="d-flex gap-3">
                                                <div class="">
                                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <circle cx="10" cy="10" r="10" fill="#7AE868" />
                                                    </svg>
                                                </div>
                                                <div class="">
                                                    <p class="id-text"><?php echo e($coform->customer_id); ?></p>
                                                    <p class="date-text">
                                                        <?php echo e($coform->created_at->todatestring()); ?></p>
                                                </div>
                                                <div class="">
                                                    <p class="name-text mb-1"> Name : <span class="name-para"><?php echo e($coform->name); ?></span></p>
                                                    <p class="name-text mb-1"> Bank : <span class="name-para"><?php echo e($coform->bank_name); ?></span>
                                                    </p>
                                                    <p class="name-text mb-1"> Mo.No : <span class="name-para"><?php echo e($coform->mobile); ?></span></p>
                                                </div>
                                            </div>
                                            <div class="">
                                                <?php if($coform->tran_status == '1'): ?>

                                                <?php else: ?>
                                            
                                                <?php endif; ?>
                                                <p class="name-text mb-1">Rs. <?php echo e($coform->get_ammount); ?> </p>
                                            </div>
                                        </div>




                                        <div class="row">


                                            <form action="<?php echo e(route('user.conformetion', $coform->sender_id)); ?>"
                                                method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('post'); ?>
                                                <div class="col-xl-12 d-flex justify-content-end gap-2">



                                                    <button type="button" class="btn btn-payment">Conformation
                                                        Done</button>


                                                    

                                                    <button type="button" class="btn btn-payment" data-toggle="modal"
                                                        data-target=".<?php echo e($coform->id); ?>-modal2-lg"
                                                        data-id="<?php echo e($coform->user_id); ?>"
                                                        data-image="<?php echo e($coform->image); ?>">View
                                                        Image</button>


                                                    <!-- Large modal -->


                                                    <div class="modal fade bd-example-modal-lg <?php echo e($coform->id); ?>-modal2-lg"
                                                        tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
                                                        aria-hidden="true">
                                                        <div class="modal-dialog modal-lg">
                                                            <div class="modal-content">

                                                                <img id="image"
                                                                    src="<?php echo e(asset('user/assets/img/payment/'.$coform->image)); ?>" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    



                                                    <?php if($coform->tran_status == '1'): ?>

                                                    <?php else: ?>

                                                    <div class="details-tip">
                                                        <button type="button"
                                                            class="btn btn-payment details-show">Details</button>
                                                        <div class="tooltip-content details-div">

                                                            <p class="name-text mb-1"> Name : <span class="name-para"><?php echo e($coform->name); ?></span>
                                                            </p>
                                                            <p class="name-text mb-1"> Mobile No. : <span
                                                                    class="name-para"><?php echo e($coform->mobile); ?></span></p>
                                                            <p class="name-text mb-1"> Ifsc Code : <span
                                                                    class="name-para"><?php echo e($coform->ifsc_code); ?></span>
                                                            </p>
                                                            <p class="name-text mb-1"> Account No: <span
                                                                    class="name-para"><?php echo e($coform->account_no); ?></span>
                                                            </p>
                                                            <p class="name-text mb-1"> Upi Link: <span
                                                                    class="name-para"><?php echo e($coform->upi_link); ?></span></p>
                                                            <p class="name-text mb-1"> Phone Pay No: <span
                                                                    class="name-para"><?php echo e($coform->phone_pay_no); ?></span>
                                                            </p>
                                                            <p class="name-text mb-1"> Google Pay No: <span
                                                                    class="name-para"><?php echo e($coform->google_pay_no); ?></span>
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>

                                                </div>

                                            </form>
                                        </div>
                                        <?php else: ?>

                                        <?php endif; ?>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</section>

<?php if(Auth::user()->status==1): ?>
<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
        class="bi bi-arrow-up-short"></i></a>
<!-- Modal-1 -->
<div class="modal fade" id="modal-2" tabindex="-1" role="dialog" aria-labelledby="modal-2Label" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header header-modify">
                <h3 class="modal-head text-center mb-0">Welcome!</h3>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">

                <div class="row">
                    <div class="col-auto">
                        <div class="">
                            <h4 class="name-text-1">Pin:</h4>
                        </div>
                        <h4 class="name-text-1">Provide Help:</h4>
                        <h4 class="name-text-1">Get Help:</h4>
                    </div>
                    <div class="col-auto">
                        <div>
                            <h4 class="name-para-1">Rs.500</h4>
                        </div>
                        <h4 class="name-para-1">Rs.1000</h4>
                        <h4 class="name-para-1">Rs.2000</h4>
                    </div>
                    <div class="mt-3 d-flex justify-content-center">
                        <button type="button" class="btn btn-form-1 w-100" data-bs-dismiss="modal"
                            aria-label="Close">Start</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php else: ?>
<?php endif; ?>

<?php if($data->ammount_Received == 'null' || $data->get_help_ammount == $data->ammount_Received || Auth::user()->status==0
): ?>
<div class="modal fade pop-modal" tabindex="-1" role="dialog" aria-hidden="true" data-bs-backdrop="static"
    data-bs-keyboard="false">
    <?php if(Session::has('error')): ?>
    <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>" style="color: red">
        <?php echo e(Session::get('error')); ?>

    </p>
    <?php endif; ?>
     
        <div class="modal-dialog modal-dialog-centered" role="document">

            <div class="modal-content">
                <div class="modal-header header-modify">

                    <p class="text-center modal-head mb-0">Enter Pin</p>
                        <form action="<?php echo e(route('logout')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <p><button type="submit" class="btn">Logout</button></p>
                        </form>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('user.pinactive', Auth::user()->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <div class="row">
                            <div class="col-xl-12 mb-3 form-class form-adjust">
                                <input class="form-control" placeholder="Please Enter a Pin" name="pin_number"></input>
                                <input type='hidden' id='hasta' value='<?php echo date(' Y-m-d'); ?>' name="date">
                                <div class="d-flex justify-content-center">
                                    <button type="submit" class="btn btn-form mt-3 w-100" data-bs-dismiss="modal"
                                        aria-label="Close" data-bs-toggle="modal"
                                        data-bs-target="#modal-2">Activate</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

            </div>
        </div>

</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
    integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"
    integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"
    integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js"
    integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous">
</script>
<script src="https://code.jquery.com/jquery-3.3.1.min.js"
    integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
<script>
    var startdate = $('#start_date_timer').val();
    var payment_success_date = $('#payment_success_date').val();
    var enddate = $('#end_date_timer').val();
    var paymentstatus = $('.payment_status').val();
    var user_Id = $('.userId').val();
    var diffTimer = moment(enddate).diff(startdate);
    var duration = moment.duration(diffTimer, 'milliseconds');
    // console.log(duration);
    var interval = 1000;
    if(paymentstatus != 1){
        setInterval(function() {
            // console.log(diffTimer);
            var diffHours = moment(enddate).diff(startdate, 'hours');
            if(diffTimer > 0){
                
                duration = moment.duration(duration - interval, 'milliseconds');
                $('#user_timer').text(diffHours+":"+moment(duration.minutes(), 'mm').format("mm")+":"+moment(duration.seconds(), 'ss').format("ss"));
                $('#user1_timer').text(diffHours+":"+moment(duration.minutes(), 'mm').format("mm")+":"+moment(duration.seconds(), 'ss').format("ss"));
            }else{
                
                $('#user_timer').text("00:00:00");
               
                var userId = $('.userId').val();
                var status = '0';
            //    var url = "<?php echo e(url('user/deactive/')); ?>";
              
                var actionUrl = "<?php echo e(url('user/deactive/')); ?>"+'/'+"<?php echo e($userId); ?>";
                    $.ajax({
						type: 'GET',
                        url: actionUrl,
						data: {
                         status: status,
						},
						success: function(data) {
							$('#result').html(data.msg);
						}
					});
            }
        }, interval);
    }else{
        var payment_success_date = $('#payment_success_date').val();
        console.log(payment_success_date);
        var enddate = $('#end_date_timer').val();
        var paymentstatus = $('.payment_status').val();
        var diffTimer = moment(enddate).diff(payment_success_date);
        var duration = moment.duration(diffTimer, 'milliseconds');
        var diffHours = moment(enddate).diff(payment_success_date, 'hours');
        if(diffTimer > 0){
            duration = moment.duration(duration - interval, 'milliseconds');
            $('#user_timer').text(diffHours+":"+moment(duration.minutes(), 'mm').format("mm")+":"+moment(duration.seconds(), 'ss').format("ss"));
            $('#user1_timer').text(diffHours+":"+moment(duration.minutes(), 'mm').format("mm")+":"+moment(duration.seconds(), 'ss').format("ss"));
            $('#user2_timer').text(diffHours+":"+moment(duration.minutes(), 'mm').format("mm")+":"+moment(duration.seconds(), 'ss').format("ss"));
        }else{
            $('#user_timer').text("00:00:00");
            $('#user1_timer').text("00:00:00");
            $('#user2_timer').text("00:00:00");
        }
    }
</script>

<script>
    function process(input) {
        let value = input.value;
        let numbers = value.replace(/[^0-9]/g, "");
        input.value = numbers;
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/umoney/resources/views/user/dashboard.blade.php ENDPATH**/ ?>