<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="card o-hidden border-0 shadow-lg my-5">
        <div class="card-body p-0">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">HELP SWITCH ON/OFF</h6>
            </div>
            <!-- DataTales Example -->

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                 <th>ID </th>
                                <th>Joinig Date </th>
                                <th>Unique No </th>
                                <th>Bank Name</th>
                                <th>Mobile No. </th>
                                <th>Id Switch On/Off </th>

                            </tr>
                        </thead>

                        <tbody>
                            <?php
                            $i = 1;
                        ?>
                            <?php if(isset($data) && !empty($data)): ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr>
                                <td><?php echo e($i); ?></td>
                                <?php echo e($list->id); ?>

                                <td><?php echo e($list->created_at); ?></td>
                                <td><?php echo e($list->customer_id); ?></td>
                                <td><?php echo e($list->bank_name); ?></td>
                                <td><?php echo e($list->mobile); ?></td>

                                <td>
                                    <?php if($list->pin_status == '0'): ?>
                                    <button class="btn btn-success btn-circle"
                                        onclick="sweetAlertAjax('get','<?php echo e(route('status', $list->id)); ?>', 'Are you sure you want to Deactivate user?')"></button>
                                    <?php else: ?>
                                    <button class="btn btn-danger btn-circle"
                                        onclick="sweetAlertAjax('get','<?php echo e(route('status', $list->id)); ?>', 'Are you sure you want to Activate user?')"></button>
                                    <?php endif; ?>
                                </td>
                                <!-- <td><button class="btn btn-success btn-circle"></button></td>
                                <td><button class="btn btn-danger btn-circle"></button></td> -->
                            </tr>
                            <?php
                                        $i++;
                                    ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-js'); ?>
<script>
    function sweetAlertAjax(type, url, title) {
            swal({
                title: title,
                icon: "warning",
                buttons: true,
                dangerMode: true,
            }).then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: url,
                        type: type,
                        data: {
                            "_token": $("#csrf-token").val(),
                        },
                        success: function(response) {
                            swal({
                                text: response.message,
                                icon: "success",
                                button: "Ok",
                            }).then(function() {
                                location.reload();
                            });
                        }
                    });
                }
            });
        }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/umoney/resources/views/admin/helpswitch.blade.php ENDPATH**/ ?>