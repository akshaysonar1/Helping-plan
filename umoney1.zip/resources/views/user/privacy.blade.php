@extends('user.layouts.master')

@section('master')
    <!-- ======= About Section ======= -->
    <section id="about" class="about section-bg">
        <div class="container" data-aos="fade-up">
            <div class="section-title">
                <h2>Privacy Policy</h2>
                <h3>Find Out More <span>Dashboard</span></h3>
                <p>Ut possimus qui ut temporibus culpa velit eveniet modi omnis est adipisci expedita at voluptas atque
                    vitae
                    autem.</p>
            </div>
        </div>
    </section>
    <section>
        <div class="container">
            <div class="col-xl-12">
                <p class="privacy-text">
                    Lorem ipsum dolor sit, amet consectetur adipisicing elit. Repellat possimus voluptates vel eos iure
                    mollitia
                    incidunt cum harum, officia quos accusantium, laudantium fugiat, totam enim. Maiores dolor
                    reiciendis
                    laborum debitis quas iure? Lorem ipsum dolor sit, amet consectetur adipisicing elit. Repellat
                    possimus voluptates vel eos iure mollitia
                    incidunt cum harum, officia quos accusantium, laudantium fugiat, totam enim. Maiores dolor
                    reiciendis
                    laborum debitis quas iure? Lorem ipsum dolor sit, amet consectetur adipisicing elit. Repellat
                    possimus voluptates vel eos iure mollitia
                    incidunt cum harum, officia quos accusantium, laudantium fugiat, totam enim. Maiores dolor
                    reiciendis
                    laborum debitis quas iure?
                </p>
            </div>
        </div>
    </section>
    <!-- End About Section -->
@endsection
