<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class pin_genrate_tabel extends Model
{
    use HasFactory;
    public $table = 'pin_genrate_tabel';
}
