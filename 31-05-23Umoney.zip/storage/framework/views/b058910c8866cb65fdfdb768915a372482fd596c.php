<header id="header" class="d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">
        <h1 class="logo"><a href="<?php echo e(route('index')); ?>"><img src="<?php echo e(asset('user/assets/img/logo.png')); ?>"
                    alt=""></a></h1>
        <nav id="navbar" class="navbar">
            <ul>
                <li><a class="nav-link scrollto" href="<?php echo e(route('index')); ?>">HOME</a></li>
                <li><a class="nav-link scrollto" href="<?php echo e(route('user.dashboard.show')); ?>">DASHBOARD</a></li>
                <li><a class="nav-link scrollto" href="<?php echo e(route('user.contact')); ?>">CONTACT US</a></li>
                <?php if(empty(Auth::user()->id) || Auth::user()->user_type == '1'): ?>
                    <li><span><a class="btn main-btn" href="<?php echo e(route('user.login')); ?>">LOGIN</a></span></li>
                <?php else: ?>
                    <li><a class="nav-link scrollto"
                            href="<?php echo e(route('user.dashboard.show')); ?>"><?php echo e(Auth::user()->name); ?></a></li>
                <?php endif; ?>
            </ul>
            <i class="bi bi-list mobile-nav-toggle"></i>
        </nav>
    </div>
</header>
<?php /**PATH /opt/lampp/htdocs/umoney/resources/views/user/layouts/header.blade.php ENDPATH**/ ?>